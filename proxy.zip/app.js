const express = require('express')
const portfinder = require('portfinder')
const app = express()
const port = 3333
const fs = require('fs')
portfinder.basePort = port
const getJson = path => {
    let content = fs.readFileSync(`${__dirname}/data.json`)
    let json = JSON.parse(content.toString())
    return json.data
}
const concatSet = (arr = [], res = {}, i) => {
    arr.forEach((item, idx) => {
        res = !item.name && !res.length ? [] : res
        if (item.data && Array.isArray(item.data) && item.data.length) {
            // debugger
            res[item.name || idx] = concatSet(item.data, void 0, idx)
            return res
        }
        res[item.name] = item.mock
        return res
    })
    return res
}
const emptyObj = {
    'code': '2000',
    'message': '接口不存在'   
}
app.all('*', (req, res) => {
    let path = req.path.indexOf('/') === 0 ? req.path.slice(1) : req.path
    let data = getJson(path)
    for (let i of data)
    {
        for (let k of i.data) {
          if (k.url === path) {
              let [param] = k.param, obj = {}
              res.json(concatSet(param.outParam) || emptyObj)
            return
          }
      }
    }    
  res.json(emptyObj)
})
portfinder.getPort((err, port) => {
    if (err) {
        console.error(err)
        return
    }
    app.listen(port, () => {
        console.log(`${port} port start`)
    })
})